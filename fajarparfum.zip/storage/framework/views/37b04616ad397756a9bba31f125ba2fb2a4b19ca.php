<div>
    <?php if (isset($component)) { $__componentOriginalae268bc92caf380291ba68f7cb95e6b90af4aa6b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SearchProduct::class, ['subcategories' => $subcategories] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-product'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SearchProduct::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae268bc92caf380291ba68f7cb95e6b90af4aa6b)): ?>
<?php $component = $__componentOriginalae268bc92caf380291ba68f7cb95e6b90af4aa6b; ?>
<?php unset($__componentOriginalae268bc92caf380291ba68f7cb95e6b90af4aa6b); ?>
<?php endif; ?>

    <div wire:loading.remove wire:target="name, subcategory_id">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="<?php if( $loop->last ): ?> mb-2 lg:mb-4 <?php endif; ?>"></div>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory => $subcategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white lg:rounded-xl p-4 lg:p-8 <?php if( !$loop->last ): ?> mb-2 lg:mb-4 <?php endif; ?>">
            <div class="section-title"><?php echo e($subcategory); ?></div>
            <div class="w-full overflow-x-auto lg:overflow-hidden">
                <table>
                    <thead>
                        <tr>
                            <td class="thead-td-left">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>No</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="thead-td w-full">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Nama</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <?php if( $category == 'Parfum' ): ?>
                            <td class="thead-td truncate">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div><span class="hidden lg:inline">Total </span>Stok</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <?php endif; ?>
                            <?php if( $subcategory != 'Parfum Refill' ): ?>
                            <td class="thead-td hidden lg:table-cell truncate">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Harga</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <?php endif; ?>
                            <td class="thead-td-right">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Pilihan</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="tbody-td-left"><?php echo e($loop->iteration); ?>.</td>
                            <td class="tbody-td"><?php echo e($product->name); ?> <?php if( $product->other_name ): ?> <span class="text-gray-600">(<?php echo e($product->other_name); ?>)</span> <?php endif; ?></td>
                            <?php if( $category == 'Parfum' ): ?>
                            <td class="tbody-td truncate">
                                <?php echo e($product->total_stock ?? 0); ?>

                            </td>
                            <?php endif; ?>
                            <?php if( $subcategory != 'Parfum Refill' ): ?>
                            <td class="tbody-td hidden lg:table-cell">Rp<?php echo e(number_format($product->price, 0, '.', '.')); ?></td>
                            <?php endif; ?>
                            <td class="tbody-td-right">
                                <?php
                                    $delete = !$product->wholesale_prices_count && !$product->outlets_count;
                                ?>
                                <?php if (isset($component)) { $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Option::class, ['first' => $loop->first,'parameter' => $product->id,'delete' => $delete] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Option::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>   
                                    <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'product.edit','routedata' => $product,'text' => 'Edit'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'product.show','routedata' => $product,'text' => 'Selengkapnya'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                        <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd" />
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'product.wholesale-price.index','routedata' => $product,'text' => 'Harga Grosir'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clip-rule="evenodd" />
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6)): ?>
<?php $component = $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6; ?>
<?php unset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6); ?>
<?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="bg-white lg:rounded-xl p-4 lg:px-8">
            <div class="font-semibold text-center">Parfum <span class="font-bold text-red-500"><?php echo e($name); ?></span> tidak ditemukan. Coba nama yang lain</div>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/livewire/product/index.blade.php ENDPATH**/ ?>