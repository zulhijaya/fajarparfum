<div>
    <div class="bg-white lg:rounded-xl p-4 lg:p-8 mb-2 lg:mb-4">
        <div class="section-title">Admin, Owner & Manager</div>
        <div class="w-full overflow-x-auto lg:overflow-hidden">
            <table>
                <thead>
                    <tr>
                        <td class="thead-td-left">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>No</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td w-full">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Nama</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="hidden lg:table-cell thead-td truncate">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Nomor Telepon</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td truncate">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Role</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td-right">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Pilihan</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="tbody-td-left"><?php echo e($loop->iteration); ?>.</td>
                        <td class="tbody-td truncate"><?php echo e($user->name); ?></td>
                        <td class="tbody-td hidden lg:table-cell"><?php echo e($user->phone); ?></td>
                        <td class="tbody-td capitalize"><?php echo e($user->role); ?></td>
                        <td class="tbody-td-right">
                            <?php if (isset($component)) { $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Option::class, ['first' => $loop->first,'parameter' => $user->id] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Option::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>   
                                <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'user.edit','routedata' => $user,'text' => 'Edit'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'user.edit','routedata' => $user,'text' => 'Selengkapnya'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                    <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd" />
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'user.edit','routedata' => $user,'text' => 'Absensi'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                    <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm9.707 5.707a1 1 0 00-1.414-1.414L9 12.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6)): ?>
<?php $component = $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6; ?>
<?php unset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6); ?>
<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="bg-white lg:rounded-xl p-4 lg:p-8">
        <div class="section-title">Karyawan</div>
        <div class="w-full overflow-x-auto lg:overflow-hidden">
            <table class="w-full table-auto">
                <thead>
                    <tr class="font-bold text-sm text-gray-500">
                        <td class="thead-td-left">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>No</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td w-full">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Nama</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td hidden lg:table-cell truncate">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Nomor Telepon</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td hidden lg:table-cell truncate">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Tempat Kerja</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Status</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                        <td class="thead-td-right">
                            <div class="flex items-center space-x-1 lg:space-x-2">
                                <div>Pilihan</div>
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                </svg>
                            </div>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="tbody-td-left"><?php echo e($loop->iteration); ?>.</td>
                        <td class="tbody-td truncate"><?php echo e($employee->name); ?></td>
                        <td class="tbody-td hidden lg:table-cell"><?php echo e($employee->phone); ?></td>
                        <td class="tbody-td hidden lg:table-cell truncate"><?php echo e($employee->outlets->implode('name', ', ')); ?></td>
                        <td class="tbody-td capitalize">
                            <?php if( $employee->status == 'bekerja' ): ?>
                            <div class="bg-green-50 flex items-center justify-center px-3 py-1.5 rounded-full">
                                <div class="text-green-500"><?php echo e($employee->status); ?></div>
                            </div>
                            <?php else: ?>
                            <div class="bg-red-50 flex items-center justify-center px-3 py-1.5 rounded-full">
                                <div class="text-red-500"><?php echo e($employee->status); ?></div>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td class="tbody-td-right">
                            <?php if (isset($component)) { $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Option::class, ['first' => $loop->first,'parameter' => $employee->id] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Option::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>   
                                <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'user.edit','routedata' => $employee,'text' => 'Edit'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'user.edit','routedata' => $employee,'text' => 'Selengkapnya'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                    <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd" />
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'user.edit','routedata' => $employee,'text' => 'Absensi'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                    <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm9.707 5.707a1 1 0 00-1.414-1.414L9 12.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6)): ?>
<?php $component = $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6; ?>
<?php unset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6); ?>
<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/livewire/user/index.blade.php ENDPATH**/ ?>