<div x-data="transaction">
    <div class="bg-white h-full p-4 lg:px-8 lg:py-4 rounded-xl mb-2 lg:mb-4">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between lg:space-x-2 space-y-4 lg:space-y-0">
            <div class="basis-full flex items-center justify-between">
                <div class="section-title mb-0">Filter</div>
                <div>
                    <label class="hidden lg:block form-label">Toko</label>
                    <select wire:model="filter.outlet_id" class="form-input w-36">
                        <option value="">Semua Toko</option>
                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($outlet->id); ?>"><?php echo e($outlet->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="flex-none flex items-center space-x-2">
                <div>
                    <label class="form-label">Tipe</label>
                    <select wire:model="filter.type" class="form-input">
                        <option value="">Semua</option>
                        <option value="eceran">Eceran</option>
                        <option value="grosir">Grosir</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">Tanggal</label>
                    <select wire:model="filter.day" class="form-input">
                        <option value=""></option>
                        <?php for( $date = 1; $date <= 31; $date++ ): ?>
                        <option value="<?php echo e($date); ?>"><?php echo e($date); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div>
                    <label class="form-label">Bulan</label>
                    <select wire:model="filter.month" class="form-input">
                        <option value="01">Januari</option>
                        <option value="02">Februari</option>
                        <option value="03">Maret</option>
                        <option value="04">April</option>
                        <option value="05">Mei</option>
                        <option value="06">Juni</option>
                        <option value="07">Juli</option>
                        <option value="08">Agustus</option>
                        <option value="09">September</option>
                        <option value="10">Oktober</option>
                        <option value="11">November</option>
                        <option value="12">Desember</option>
                    </select>
                </div>
                <div>
                    <label class="form-label">Tahun</label>
                    <select wire:model="filter.year" class="form-input">
                        <option value="2022">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    
    <div wire:loading.remove>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $listOrders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
        <div class="bg-white lg:rounded-xl p-4 lg:p-8 mb-2 lg:mb-4">
            <div class="flex items-center justify-between mb-5">
                <div class="section-title mb-0"><?php echo e($date); ?></div>
                <div class="font-semibold"><span class="text-gray-600">Total : </span>Rp<?php echo e(number_format($listOrders->sum('total'), 0, '.', '.')); ?></div>
            </div>
            <div class="w-full overflow-x-auto lg:overflow-hidden">
                <table>
                    <thead>
                        <tr>
                            <td class="thead-td-left">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>No</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="thead-td">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Invoice</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="thead-td w-full">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Customer</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="hidden lg:table-cell thead-td">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Qty</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="hidden lg:table-cell thead-td">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Jam</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="thead-td">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Total</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                            <td class="hidden lg:table-cell thead-td-right">
                                <div class="flex items-center space-x-1 lg:space-x-2">
                                    <div>Kembalian</div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $listOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="tbody-td-left"><?php echo e($loop->iteration); ?>.</td>
                            <td class="tbody-td truncate"><?php echo e($order->invoice); ?></td>
                            <td class="tbody-td"><?php echo e($order->user_id ? $order->user->name : 'Bukan Member'); ?></td>
                            <td class="hidden lg:table-cell tbody-td"><?php echo e($order->total_qty); ?></td>
                            <td class="hidden lg:table-cell tbody-td"><?php echo e($order->created_at->format('H:i')); ?></td>
                            <td class="tbody-td">Rp<?php echo e(number_format($order->total, 0, '.', '.')); ?></td>
                            <td class="hidden lg:table-cell tbody-td">Rp<?php echo e(number_format($order->change, 0, '.', '.')); ?></td>
                            <td class="tbody-td-right">
                                <?php if (isset($component)) { $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Option::class, ['first' => $loop->first,'parameter' => $order->id,'delete' => false] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Option::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>   
                                    <div x-on:click="showOrderDetail(<?php echo e($order); ?>)" class="hover:bg-gray-200 rounded-t-lg flex items-center space-x-2 px-5 py-2.5 lg:py-2 cursor-pointer">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 lg:h-4 lg:w-4" viewBox="0 0 20 20" fill="currentColor">
                                            <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                            <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd" />
                                        </svg>
                                        <div class="truncate">Selengkapnya</div>
                                    </div>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6)): ?>
<?php $component = $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6; ?>
<?php unset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6); ?>
<?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="bg-white lg:rounded-xl p-4 lg:px-8">
            <div class="font-semibold text-center">Laporan transaksi tidak ditemukan</div>
        </div>
        <?php endif; ?>
    </div>
    <div wire:loading.block class="bg-white lg:rounded-xl p-4 lg:px-8">
        <div class="flex items-center justify-center space-x-2">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="background: none; display: block; shape-rendering: auto;" class="w-6 h-6" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#1f2937" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round">
                <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" keyTimes="0;1" values="0 50 50;360 50 50"></animateTransform>
                </circle>
            </svg>
            <div class="font-semibold">Tunggu sebentar ...</div>
        </div>
    </div>

    <div x-show="openOrderDetail" class="fixed inset-0 bg-black bg-opacity-30 z-40" x-cloak>
        <div class="flex items-center lg:justify-center w-full h-full p-4 lg:py-0 overscroll-contain">
            <section name="set-outlet" x-on:click.outside="openOrderDetail = false; order = []" class="bg-white w-full lg:w-1/3 max-h-full overflow-y-auto rounded-xl px-4 pb-4 lg:p-8 font-semibold overscroll-contain">
                <div class="sticky lg:relative top-0 lg:top-auto bg-white section-title pt-4 pb-2 lg:py-0 mb-4" x-text="'Detail Orderan ' + (order.user_id ? order.user.name : '')"></div>
                <div class="flex items-center justify-between mb-2">
                    <div x-text="order.invoice"></div>
                    <div><span class="text-gray-600">Jam : </span><span x-text="getOrderHour(order.created_at)"></span></div>
                </div>
                <div class="flex flex-col space-y-2 mb-4">
                    <template x-for="(order, index) in order.order_details">
                    <div class="border-b border-gray-200 pb-2 mb-2">
                        <h6>
                            <template x-for="(product, i) in order.products">
                                <span>
                                    <span x-text="product.name"></span>
                                    <span x-show="order.bottle" class="text-gray-600" x-text="'(' + product.pivot.seed + ')'"></span><span x-show="i != order.products.length - 1">,</span>
                                </span>
                            </template>
                            <span x-show="order.bottle">
                                <span x-text="'&middot; ' + order.bottle + 'ml'"></span>
                                <span class="text-gray-600" x-text="'(' + order.dosing_type + ')'"></span>
                            </span>
                        </h6>
                        <div class="flex items-center justify-between mt-3">
                            <h6 class="font-semibold" x-text="order.price != 0 ? formatedPrice(order.price * order.qty) : 'Bonus'"></h6>
                            <div class="font-semibold" x-text="'x' + order.qty"></div>
                        </div>
                    </div>
                    </template>
                </div>  
                <div class="flex justify-end">
                    <div>
                        <table>
                            <tr>
                                <td class="pb-1 text-gray-600 pr-1">Total</td>
                                <td class="pb-1" x-text="': ' + formatedPrice(order.total)"></td>
                            </tr>
                            <tr>
                                <td class="text-gray-600 pr-1">Kembalian</td>
                                <td x-text="': ' + formatedPrice(order.change)"></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
 
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('transaction', () => ({
                order: [],
                openOrderDetail: false,

                showOrderDetail(order) {
                    this.$dispatch('tes')
                    this.order = order
                    this.openOrderDetail = true
                },
            
                formatedPrice(price) {
                    return 'Rp' + new Intl.NumberFormat('id-ID').format(price)
                },

                getOrderHour(createdAt) {
                    const time = new Date(createdAt)
                    return time.getHours() + ":" + time.getMinutes()
                }
            }))
        })
    </script>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/livewire/report/transaction.blade.php ENDPATH**/ ?>