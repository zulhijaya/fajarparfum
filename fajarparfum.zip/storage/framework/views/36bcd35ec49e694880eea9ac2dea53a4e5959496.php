<div x-data class="bg-white">
    <div class="mx-4 lg:mx-10 border-b border-gray-100 py-3">
        <div class="flex items-center justify-between">
            <button x-on:click="$dispatch('open-sidebar')" class="lg:hidden focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="fill-gray-400 hover:fill-gray-600 h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd" />
                </svg>
            </button>
            <h1 class="font-extrabold text-lg xl:text-xl"><?php echo e(count($titles) ? $titles[count($titles) - 1]['name'] : 'Dashboard'); ?></h1>
            <div class="flex items-center">
                <div class="hidden lg:flex items-centet">
                    
                    <div class="hidden lg:flex items-center text-gray-500">
                        <div class="font-semibold text-xs lg:text-sm mr-0.5"><?php echo e(Auth::user()->name); ?></div>
                        <div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="px-4 lg:px-10 shadow-sm py-2">
        <div class="flex items-center justify-between">
            <div class="overflow-x-auto">
                <div class="flex items-center space-x-1 font-semibold text-xs lg:text-sm">
                    <a href="<?php echo e(route('dashboard')); ?>" class="flex-auto <?php if( count($titles) != 0 ): ?> text-gray-400 <?php endif; ?>">Dashboard</a>
                    <?php if( count($titles) ): ?>
                        <div class="flex items-center space-x-1">
                        <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="<?php if( !$loop->last ): ?> fill-gray-400 <?php endif; ?> h-3 w-3 lg:h-4 lg:w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                            </svg>
                            <?php if( !$loop->last ): ?>
                            <a href="<?php echo e(route($title['route'])); ?>" class="text-gray-400 truncate"><?php echo e($title['name']); ?></a>
                            <?php else: ?> 
                            <div class="truncate"><?php echo e($title['name']); ?></div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if( $create['route'] ): ?>
            <?php if (isset($component)) { $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Option::class, ['first' => true,'delete' => false] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Option::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>   
                <a href="<?php echo e(route($create['route'], $create['parameter'])); ?>">
                    <div class="hover:bg-gray-200 rounded-t-lg flex items-center space-x-2 px-5 py-2.5 lg:py-2 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 lg:h-4 lg:w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm5 6a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V8z" clip-rule="evenodd" />
                        </svg>
                        <div class="">Tambah</div>
                    </div>
                </a>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6)): ?>
<?php $component = $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6; ?>
<?php unset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6); ?>
<?php endif; ?>
            
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/components/header.blade.php ENDPATH**/ ?>