<div class="bg-white rounded-lg px-4 pt-4 pb-8 lg:p-8 min-h-full">
    <form wire:submit.prevent="store" class="font-medium">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="<?php if( !$loop->last ): ?> mb-8 <?php endif; ?>">
            <div class="flex items-center justify-between">
                <label for="" class="form-label mb-2"><?php echo e($index); ?></label>
                <label for="select-all" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="selectAll" id="select-all" type="checkbox" class="flex-shrink-0 w-4 h-4  accent-blue-500 cursor-pointer focus:outline-none" checked>
                    <span class="truncate">Pilih semua</span>
                </label>
            </div>
            <div class="grid grid-cols-2 lg:grid-cols-6 gap-4">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label for="<?php echo e($product->name); ?>" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="product_ids" id="<?php echo e($product->name); ?>" type="checkbox" value="<?php echo e($product->id); ?>" class="target flex-shrink-0 w-4 h-4  accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate"><?php echo e($product->name); ?> <?php if( $product->size ): ?> (<?php echo e($product->size); ?>) <?php endif; ?></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__errorArgs = ['product_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error mt-6"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FormButton::class, ['route' => 'outlet.stock.index','parameter' => $outlet->id,'button' => 'Tambah'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
    </form>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/livewire/outlet/stock/create.blade.php ENDPATH**/ ?>