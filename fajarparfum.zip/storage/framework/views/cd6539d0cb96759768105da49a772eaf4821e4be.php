<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

        <title>Fajar Parfum - Login</title>
</head>
<body class="font-urbanist antialiased text-gray-800">
    <div class="flex items-center justify-center h-screen">
        <div class="flex flex-col items-center w-full lg:w-1/5 px-4 lg:px-0">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="w-full">
                <?php echo csrf_field(); ?>
                <div class="mb-10">
                    <h1 class="font-extrabold text-4xl text-center">Fajar Parfum</h1>
                    <div class="text-sm font-semibold text-gray-500 mt-4">Selamat datang di Fajar Parfum. Login ke akun Anda untuk masuk.</div>
                </div>

                <!-- Session Status -->
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <div class="mb-4">
                    <label class="form-label">Nomor Telepon</label>
                    <input type="text" name="phone" class="form-input" placeholder="masukkan nomor telepon" value="<?php echo e(old('phone')); ?>" required autofocus>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-input" placeholder="masukkan password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <button class="bg-gray-800 hover:bg-gray-900 text-white font-bold rounded-lg border border-gray-800 px-4 py-1.5 cursor-pointer w-full mt-8">Login</button>
            </form>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/auth/login.blade.php ENDPATH**/ ?>