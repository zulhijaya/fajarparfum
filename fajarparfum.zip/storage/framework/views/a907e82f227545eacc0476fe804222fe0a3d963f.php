<div class="bg-white rounded-lg px-4 pt-4 pb-8 lg:p-8 min-h-full">
    <form wire:submit.prevent="update" class="font-medium">
        <div class="form-mb">
            <label class="form-label">Nama :</label>
            <input wire:model.defer="user.name" type="text" class="form-input" placeholder="masukkan nama">
            <?php $__errorArgs = ['user.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-mb">
            <label class="form-label">Nomor Telepon :</label>
            <input wire:model.defer="user.phone" type="number" class="form-input" placeholder="masukkan nomor telepon">
            <?php $__errorArgs = ['user.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-mb">
            <label class="form-label">Email :</label>
            <input wire:model.defer="user.email" type="email" class="form-input" placeholder="masukkan email">
            <?php $__errorArgs = ['user.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-mb">
            <label class="form-label">Password :</label>
            <input wire:model.defer="password" type="password" class="form-input" placeholder="masukkan password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-mb">
            <label class="form-label">Konfirmasi Password :</label>
            <input wire:model.defer="password_confirmation" type="password" class="form-input" placeholder="masukkan konfirmasi password">
        </div>
        <?php if( $old_role != 'admin' ): ?>
        <div class="form-mb">
            <label class="form-label">Role :</label>
            <div class="grid grid-cols-2 lg:grid-cols-12 gap-y-2">
                <label for="admin" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="user.role" id="admin" type="radio" name="type" value="admin" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Admin</span>
                </label>
                <label for="owner" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="user.role" id="owner" type="radio" name="type" value="owner" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Owner</span>
                </label>
                <label for="manager" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="user.role" id="manager" type="radio" name="type" value="manager" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Manager</span>
                </label>
                <label for="employee" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="user.role" id="employee" type="radio" name="type" value="employee" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Employee</span>
                </label>
            </div>
            <?php $__errorArgs = ['user.role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php endif; ?>
        <div class="form-mb">
            <label class="form-label">Tempat Kerja :</label>
            <div class="flex flex-col space-y-2">
                <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label for="<?php echo e($outlet->name); ?>" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model="outlet_ids" id="<?php echo e($outlet->name); ?>" type="checkbox" name="outlet" value="<?php echo e($outlet->id); ?>" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate"><?php echo e($outlet->name); ?> <span class="text-gray-600 capitalize">(<?php echo e($outlet->type); ?>)</span></span>
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__errorArgs = ['outlet_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if( $user->role == 'employee' ): ?>
        <div class="form-mb">
            <label class="form-label">Jam Kerja :</label>
            <div class="grid grid-cols-2 lg:grid-cols-12 gap-y-1">
                <label for="full-time" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model.defer="user.working_hours" id="full-time" type="radio" name="working-hours" value="full-time" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Full-Time</span>
                </label>
                <label for="part-time" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model.defer="user.working_hours" id="part-time" type="radio" name="working-hours" value="part-time" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Part-time</span>
                </label>
            </div>
            <?php $__errorArgs = ['user.working_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="form-label">Status :</label>
            <div class="grid grid-cols-2 lg:grid-cols-12 gap-y-1">
                <label for="bekerja" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model.defer="user.status" id="bekerja" type="radio" name="status" value="bekerja" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Bekerja</span>
                </label>
                <label for="berhenti" class="group flex items-center space-x-2 cursor-pointer">
                    <input wire:model.defer="user.status" id="berhenti" type="radio" name="status" value="berhenti" class="w-3.5 h-3.5 accent-blue-500 cursor-pointer focus:outline-none">
                    <span class="truncate">Berhenti</span>
                </label>
            </div>
            <?php $__errorArgs = ['user.status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FormButton::class, ['route' => 'user.index','parameter' => '','button' => 'Update'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\FormButton::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415)): ?>
<?php $component = $__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415; ?>
<?php unset($__componentOriginal52f94bf65e72e08a0c6331cd313cc3a15eb70415); ?>
<?php endif; ?>
    </form>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/livewire/user/edit.blade.php ENDPATH**/ ?>