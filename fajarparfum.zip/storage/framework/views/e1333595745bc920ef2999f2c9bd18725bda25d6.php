<div class="flex items-center justify-end space-x-2 mt-8">
    <a href="<?php echo e(route($route, $parameter)); ?>">
        <button type="button" class="form-cancel-button">Batal</button>
    </a>
    <button class="form-confirm-button"><?php echo e($button); ?></button>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/components/form-button.blade.php ENDPATH**/ ?>