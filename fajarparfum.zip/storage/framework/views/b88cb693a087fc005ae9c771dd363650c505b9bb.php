<div>
    <div class="bg-white lg:rounded-xl p-4 lg:p-8">
        <table class="mb-28">
            <thead>
                <tr>
                    <td class="thead-td-left">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>No</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                    <td class="thead-td w-full lg:w-auto">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>Nama</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                    <td class="thead-td hidden lg:table-cell w-full">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>Alamat</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                    <td class="thead-td hidden lg:table-cell truncate">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>Karyawan</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                    <td class="thead-td truncate">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>Tipe</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                    <td class="thead-td hidden lg:table-cell truncate">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>Status</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                    <td class="thead-td-right">
                        <div class="flex items-center space-x-1 lg:space-x-2">
                            <div>Pilihan</div>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="tbody-td-left"><?php echo e($loop->iteration); ?>.</td>
                    <td class="tbody-td lg:truncate"><?php echo e($outlet->name); ?></td>
                    <td class="tbody-td hidden lg:table-cell"><?php echo e($outlet->address); ?></td>
                    <td class="tbody-td hidden lg:table-cell"><?php echo e($outlet->employees_count); ?> org</td>
                    <td class="tbody-td capitalize truncate"><?php echo e($outlet->type); ?></td>
                    <td class="tbody-td hidden lg:table-cell capitalize">
                        <?php if( $outlet->status == 'buka' ): ?>
                        <div class="bg-green-50 flex items-center justify-center px-3 py-1.5 rounded-full">
                            <div class="text-green-500"><?php echo e($outlet->status); ?></div>
                        </div>
                        <?php elseif( $outlet->status == 'tutup' ): ?>
                        <div class="bg-red-50 flex items-center justify-center px-3 py-1.5 rounded-full">
                            <div class="text-red-500"><?php echo e($outlet->status); ?></div>
                        </div>
                        <?php else: ?>
                        <div class="bg-red-500 flex items-center justify-center px-3 py-1.5 rounded-full">
                            <div class="text-white"><?php echo e($outlet->status); ?></div>
                        </div>
                        <?php endif; ?>
                    </td>
                    <td class="tbody-td-right">
                        <?php if (isset($component)) { $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Option::class, ['first' => $loop->first,'parameter' => $outlet->id,'delete' => !$outlet->stocks_count && !$outlet->employees_count] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Option::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>   
                            <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'outlet.edit','routedata' => $outlet,'text' => 'Edit'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'outlet.show','routedata' => $outlet,'text' => 'Selengkapnya'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd" />
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'outlet.stock.index','routedata' => $outlet,'text' => 'Stok'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd" />
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                            <?php if( $outlet->type == 'toko utama' && $outlet->stocks_count ): ?>
                            <?php if (isset($component)) { $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\OptionLink::class, ['route' => 'outlet.stock.send','routedata' => $outlet,'text' => 'Kirim Stok'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('option-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\OptionLink::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3)): ?>
<?php $component = $__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3; ?>
<?php unset($__componentOriginal2f545e78fa19c7cbb50ec128f3b6a38a91acecf3); ?>
<?php endif; ?>
                            <?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6)): ?>
<?php $component = $__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6; ?>
<?php unset($__componentOriginal5b95222ba631b6a2f496c127eafb27b814614da6); ?>
<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\Users\ZULO\Desktop\New Project\Fajar Parfum\backend.fajarparfum\resources\views/livewire/outlet/index.blade.php ENDPATH**/ ?>