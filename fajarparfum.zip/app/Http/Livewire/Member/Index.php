<?php

namespace App\Http\Livewire\Member;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.member.index');
    }
}
